
public class mainclass
{
	public static void main(String[] args)
	{
		fileclass r=new fileclass();
		r.openFile();
		r.readFile();
		r.closeFile();
		bodyclass s=new bodyclass();
	}
	
}